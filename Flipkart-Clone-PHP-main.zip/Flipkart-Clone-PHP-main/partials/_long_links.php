    <!-- long desc links -->
    <div class="w-full bg-white p-6 flex flex-col mt-10 border-t text-gray-500 text-sm">
        <h3 class="font-medium mb-3">Top Stories: <span class="text-gray-700">Brand Directory</span></h3>

        <p class="">MOST SEARCHED FOR ON FLIPKART:
            <span class="text-xxs text-gray-700">
                <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> |
                <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> |
                <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> |
                <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> |
                <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> |
                <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a> | <a href="#">iPhone 13 Pro</a>
            </span>
        </p>

        <p>LARGE APPLIANCES:
            <span class="text-xxs text-gray-700">
                <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> |
                <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> |
                <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> |
                <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> | <a href="#">Refrigerators</a> |
           </span>
        </p>

        <p>GROCERIES:
            <span class="text-xxs text-gray-700">
                <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> |
                <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> |
                <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> |
                <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a> | <a href="#">Dal Pulses</a>
            </span>
        </p>

        <p>FOOTWEAR:
            <span class="text-xxs text-gray-700">
                <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> |
                <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> |
                <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> |
                <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a> | <a href="#">Adidas Shoes</a>
            </span>
        </p>

        <p>BEST SELLING ON FLIPKART:
            <span class="text-xxs text-gray-700">
                <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> |
                <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> |
                <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a> | <a href="#">Books</a>
            </span>
        </p>

    </div>
    <!-- long desc links -->